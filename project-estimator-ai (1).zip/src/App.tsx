/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { 
  Calculator, 
  Clock, 
  Users, 
  DollarSign, 
  AlertTriangle, 
  Plus, 
  Trash2, 
  ChevronRight, 
  BarChart3,
  CheckCircle2,
  Info,
  Layers
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Types
type RiskLevel = 'Low' | 'Medium' | 'High';

interface Task {
  id: string;
  name: string;
  effort: number; // in hours
  dependency?: string; // id of task it depends on
}

interface ProjectData {
  name: string;
  type: string;
  tasks: Task[];
  teamSize: number;
  resourceRate: number; // per hour
  riskLevel: RiskLevel;
}

const PROJECT_TYPES = [
  'Software Development',
  'Construction',
  'Event Planning',
  'Research & Development',
  'Marketing Campaign',
  'Product Launch',
  'Other'
];

export default function App() {
  const [step, setStep] = useState<'input' | 'result'>('input');
  const [project, setProject] = useState<ProjectData>({
    name: '',
    type: 'Software Development',
    tasks: [
      { id: '1', name: 'Planning & Requirements', effort: 40 },
      { id: '2', name: 'Design', effort: 60 },
      { id: '3', name: 'Development', effort: 120 },
      { id: '4', name: 'Testing', effort: 40 },
      { id: '5', name: 'Deployment', effort: 20 },
    ],
    teamSize: 3,
    resourceRate: 50,
    riskLevel: 'Medium',
  });

  const addTask = () => {
    const newId = (project.tasks.length + 1).toString();
    setProject({
      ...project,
      tasks: [...project.tasks, { id: newId, name: '', effort: 0 }]
    });
  };

  const removeTask = (id: string) => {
    if (project.tasks.length <= 1) return;
    setProject({
      ...project,
      tasks: project.tasks.filter(t => t.id !== id)
    });
  };

  const updateTask = (id: string, field: keyof Task, value: any) => {
    setProject({
      ...project,
      tasks: project.tasks.map(t => t.id === id ? { ...t, [field]: value } : t)
    });
  };

  // Calculations
  const analysis = useMemo(() => {
    const totalWorkHours = project.tasks.reduce((sum, t) => sum + t.effort, 0);
    const baseCost = totalWorkHours * project.resourceRate;
    
    let bufferPercent = 0.05;
    if (project.riskLevel === 'Medium') bufferPercent = 0.10;
    if (project.riskLevel === 'High') bufferPercent = 0.15;
    
    const contingency = baseCost * bufferPercent;
    const finalCost = baseCost + contingency;
    
    // Simple timeline estimation: 
    // Assuming team works 40 hours a week total (8 hours per person per day)
    const dailyTeamCapacity = project.teamSize * 8;
    const durationDays = Math.ceil(totalWorkHours / dailyTeamCapacity);
    const bufferDays = Math.ceil(durationDays * bufferPercent);
    const finalDurationDays = durationDays + bufferDays;

    return {
      totalWorkHours,
      baseCost,
      contingency,
      finalCost,
      durationDays,
      bufferDays,
      finalDurationDays,
      bufferPercent: bufferPercent * 100
    };
  }, [project]);

  const handleEstimate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!project.name) {
      alert("Please enter a project name");
      return;
    }
    setStep('result');
  };

  return (
    <div className="min-h-screen bg-[#E4E3E0] text-[#141414] font-sans selection:bg-[#141414] selection:text-[#E4E3E0]">
      {/* Header */}
      <header className="border-b border-[#141414] p-6 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <Layers className="w-8 h-8" />
          <h1 className="text-2xl font-bold tracking-tighter uppercase italic font-serif">
            Project Estimator <span className="not-italic opacity-50">AI</span>
          </h1>
        </div>
        <div className="text-xs font-mono uppercase tracking-widest opacity-50">
          Professional Planning Analyst v1.0
        </div>
      </header>

      <main className="max-w-6xl mx-auto p-6 md:p-12">
        <AnimatePresence mode="wait">
          {step === 'input' ? (
            <motion.div
              key="input-form"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="grid grid-cols-1 lg:grid-cols-3 gap-12"
            >
              {/* Left Column: Basic Info */}
              <div className="lg:col-span-1 space-y-8">
                <section className="space-y-4">
                  <h2 className="text-xs font-mono uppercase tracking-widest opacity-50 border-b border-[#141414] pb-2">
                    01. Project Identity
                  </h2>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-[11px] uppercase font-serif italic mb-1">Project Name</label>
                      <input 
                        type="text" 
                        value={project.name}
                        onChange={e => setProject({...project, name: e.target.value})}
                        placeholder="e.g. Apollo Website Redesign"
                        className="w-full bg-transparent border-b border-[#141414] py-2 focus:outline-none focus:border-opacity-50 transition-all"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] uppercase font-serif italic mb-1">Project Type</label>
                      <select 
                        value={project.type}
                        onChange={e => setProject({...project, type: e.target.value})}
                        className="w-full bg-transparent border-b border-[#141414] py-2 focus:outline-none appearance-none cursor-pointer"
                      >
                        {PROJECT_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
                      </select>
                    </div>
                  </div>
                </section>

                <section className="space-y-4">
                  <h2 className="text-xs font-mono uppercase tracking-widest opacity-50 border-b border-[#141414] pb-2">
                    02. Resources & Risk
                  </h2>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[11px] uppercase font-serif italic mb-1">Team Size</label>
                      <div className="flex items-center gap-2 border-b border-[#141414] py-2">
                        <Users className="w-4 h-4 opacity-50" />
                        <input 
                          type="number" 
                          value={project.teamSize}
                          onChange={e => setProject({...project, teamSize: parseInt(e.target.value) || 1})}
                          className="w-full bg-transparent focus:outline-none"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-[11px] uppercase font-serif italic mb-1">Rate ($/hr)</label>
                      <div className="flex items-center gap-2 border-b border-[#141414] py-2">
                        <DollarSign className="w-4 h-4 opacity-50" />
                        <input 
                          type="number" 
                          value={project.resourceRate}
                          onChange={e => setProject({...project, resourceRate: parseInt(e.target.value) || 0})}
                          className="w-full bg-transparent focus:outline-none"
                        />
                      </div>
                    </div>
                  </div>
                  <div>
                    <label className="block text-[11px] uppercase font-serif italic mb-1">Risk Level</label>
                    <div className="flex gap-2 pt-2">
                      {(['Low', 'Medium', 'High'] as RiskLevel[]).map(level => (
                        <button
                          key={level}
                          onClick={() => setProject({...project, riskLevel: level})}
                          className={`flex-1 py-2 text-[10px] uppercase tracking-tighter border border-[#141414] transition-all ${
                            project.riskLevel === level ? 'bg-[#141414] text-[#E4E3E0]' : 'hover:bg-[#141414] hover:text-[#E4E3E0]'
                          }`}
                        >
                          {level}
                        </button>
                      ))}
                    </div>
                  </div>
                </section>

                <button 
                  onClick={handleEstimate}
                  className="w-full group bg-[#141414] text-[#E4E3E0] py-6 flex items-center justify-center gap-3 hover:bg-opacity-90 transition-all"
                >
                  <span className="text-lg font-bold uppercase tracking-widest">Generate Analysis</span>
                  <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>

              {/* Right Column: Tasks (WBS) */}
              <div className="lg:col-span-2 space-y-6">
                <div className="flex justify-between items-end border-b border-[#141414] pb-2">
                  <h2 className="text-xs font-mono uppercase tracking-widest opacity-50">
                    03. Work Breakdown Structure
                  </h2>
                  <button 
                    onClick={addTask}
                    className="flex items-center gap-1 text-[10px] uppercase font-bold hover:opacity-50 transition-opacity"
                  >
                    <Plus className="w-3 h-3" /> Add Task
                  </button>
                </div>

                <div className="space-y-2 max-h-[600px] overflow-y-auto pr-2 custom-scrollbar">
                  {project.tasks.map((task, index) => (
                    <motion.div 
                      layout
                      key={task.id}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="group flex items-center gap-4 p-4 border border-[#141414] hover:bg-[#141414] hover:text-[#E4E3E0] transition-all"
                    >
                      <span className="text-xs font-mono opacity-30 group-hover:opacity-50">{(index + 1).toString().padStart(2, '0')}</span>
                      <input 
                        type="text" 
                        value={task.name}
                        onChange={e => updateTask(task.id, 'name', e.target.value)}
                        placeholder="Task description..."
                        className="flex-1 bg-transparent focus:outline-none text-sm font-medium"
                      />
                      <div className="flex items-center gap-2 border-l border-[#141414] group-hover:border-[#E4E3E0] pl-4">
                        <input 
                          type="number" 
                          value={task.effort}
                          onChange={e => updateTask(task.id, 'effort', parseInt(e.target.value) || 0)}
                          className="w-16 bg-transparent focus:outline-none text-right font-mono text-sm"
                        />
                        <span className="text-[10px] uppercase opacity-50">Hrs</span>
                      </div>
                      <button 
                        onClick={() => removeTask(task.id)}
                        className="opacity-0 group-hover:opacity-100 p-1 hover:text-red-400 transition-all"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </motion.div>
                  ))}
                </div>
                
                <div className="p-4 bg-[#141414] bg-opacity-5 border border-[#141414] flex justify-between items-center">
                  <span className="text-[10px] uppercase font-mono opacity-50">Total Estimated Effort</span>
                  <span className="text-xl font-bold font-mono">{analysis.totalWorkHours} <span className="text-xs font-normal opacity-50">HRS</span></span>
                </div>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="result-view"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              className="space-y-12"
            >
              {/* Result Header */}
              <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-b-2 border-[#141414] pb-8">
                <div>
                  <button 
                    onClick={() => setStep('input')}
                    className="text-[10px] uppercase font-bold mb-4 flex items-center gap-1 hover:opacity-50 transition-opacity"
                  >
                    <ChevronRight className="w-3 h-3 rotate-180" /> Back to Editor
                  </button>
                  <h2 className="text-5xl font-bold tracking-tighter uppercase italic font-serif leading-none">
                    {project.name}
                  </h2>
                  <p className="mt-2 text-sm opacity-60 uppercase tracking-widest font-mono">
                    {project.type} • {project.riskLevel} Risk Profile
                  </p>
                </div>
                <div className="flex gap-4">
                  <div className="text-right">
                    <p className="text-[10px] uppercase opacity-50 font-mono">Final Estimated Cost</p>
                    <p className="text-4xl font-bold font-mono">${analysis.finalCost.toLocaleString()}</p>
                  </div>
                  <div className="w-px h-12 bg-[#141414] opacity-20 hidden md:block" />
                  <div className="text-right">
                    <p className="text-[10px] uppercase opacity-50 font-mono">Estimated Duration</p>
                    <p className="text-4xl font-bold font-mono">{analysis.finalDurationDays} <span className="text-lg">DAYS</span></p>
                  </div>
                </div>
              </div>

              {/* Analysis Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
                {/* Left: Task Breakdown */}
                <div className="lg:col-span-2 space-y-8">
                  <section>
                    <h3 className="text-xs font-mono uppercase tracking-widest opacity-50 mb-4 flex items-center gap-2">
                      <BarChart3 className="w-4 h-4" /> Detailed Task Breakdown
                    </h3>
                    <div className="border border-[#141414]">
                      <div className="grid grid-cols-12 bg-[#141414] text-[#E4E3E0] p-3 text-[10px] uppercase font-mono tracking-widest">
                        <div className="col-span-1">ID</div>
                        <div className="col-span-7">Task Description</div>
                        <div className="col-span-2 text-right">Effort</div>
                        <div className="col-span-2 text-right">Cost</div>
                      </div>
                      {project.tasks.map((task, i) => (
                        <div key={task.id} className="grid grid-cols-12 p-3 border-b border-[#141414] last:border-0 text-sm items-center hover:bg-[#141414] hover:text-[#E4E3E0] transition-colors group">
                          <div className="col-span-1 font-mono opacity-50">{(i + 1).toString().padStart(2, '0')}</div>
                          <div className="col-span-7 font-medium">{task.name}</div>
                          <div className="col-span-2 text-right font-mono">{task.effort}h</div>
                          <div className="col-span-2 text-right font-mono">${(task.effort * project.resourceRate).toLocaleString()}</div>
                        </div>
                      ))}
                    </div>
                  </section>

                  <section>
                    <h3 className="text-xs font-mono uppercase tracking-widest opacity-50 mb-4 flex items-center gap-2">
                      <Clock className="w-4 h-4" /> Timeline Projection
                    </h3>
                    <div className="space-y-6">
                      <div className="relative h-4 bg-[#141414] bg-opacity-10 overflow-hidden">
                        <motion.div 
                          initial={{ width: 0 }}
                          animate={{ width: '100%' }}
                          transition={{ duration: 1.5, ease: "easeOut" }}
                          className="absolute inset-y-0 left-0 bg-[#141414]"
                        />
                        <div className="absolute inset-y-0 left-[80%] w-px bg-[#E4E3E0] z-10" />
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div className="p-4 border border-[#141414]">
                          <p className="text-[10px] uppercase opacity-50 mb-1">Base Duration</p>
                          <p className="text-xl font-bold font-mono">{analysis.durationDays} Days</p>
                        </div>
                        <div className="p-4 border border-[#141414]">
                          <p className="text-[10px] uppercase opacity-50 mb-1">Risk Buffer</p>
                          <p className="text-xl font-bold font-mono">+{analysis.bufferDays} Days</p>
                        </div>
                        <div className="p-4 border border-[#141414]">
                          <p className="text-[10px] uppercase opacity-50 mb-1">Team Capacity</p>
                          <p className="text-xl font-bold font-mono">{project.teamSize * 8}h / Day</p>
                        </div>
                        <div className="p-4 border border-[#141414]">
                          <p className="text-[10px] uppercase opacity-50 mb-1">Workload</p>
                          <p className="text-xl font-bold font-mono">{analysis.totalWorkHours}h Total</p>
                        </div>
                      </div>
                    </div>
                  </section>
                </div>

                {/* Right: Financial & Risk */}
                <div className="space-y-8">
                  <section className="p-6 bg-[#141414] text-[#E4E3E0] space-y-6">
                    <h3 className="text-xs font-mono uppercase tracking-widest opacity-50 flex items-center gap-2">
                      <Calculator className="w-4 h-4" /> Cost Calculation
                    </h3>
                    <div className="space-y-4">
                      <div className="flex justify-between items-end border-b border-[#E4E3E0] border-opacity-20 pb-2">
                        <span className="text-xs uppercase opacity-60">Base Labor</span>
                        <span className="font-mono">${analysis.baseCost.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between items-end border-b border-[#E4E3E0] border-opacity-20 pb-2">
                        <span className="text-xs uppercase opacity-60">Risk Contingency ({analysis.bufferPercent}%)</span>
                        <span className="font-mono text-amber-400">+${analysis.contingency.toLocaleString()}</span>
                      </div>
                      <div className="pt-4">
                        <div className="flex justify-between items-end">
                          <span className="text-sm font-bold uppercase tracking-widest">Total Estimate</span>
                          <span className="text-3xl font-bold font-mono">${analysis.finalCost.toLocaleString()}</span>
                        </div>
                      </div>
                    </div>
                  </section>

                  <section className="space-y-4">
                    <h3 className="text-xs font-mono uppercase tracking-widest opacity-50 flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4" /> Risk Assessment
                    </h3>
                    <div className={`p-4 border-l-4 ${
                      project.riskLevel === 'Low' ? 'border-green-500 bg-green-500/5' :
                      project.riskLevel === 'Medium' ? 'border-amber-500 bg-amber-500/5' :
                      'border-red-500 bg-red-500/5'
                    }`}>
                      <p className="text-sm font-bold uppercase mb-1">{project.riskLevel} Risk Level</p>
                      <p className="text-xs opacity-70 leading-relaxed">
                        {project.riskLevel === 'Low' && "Project has well-defined requirements and stable resources. Minimal buffer applied."}
                        {project.riskLevel === 'Medium' && "Standard project complexity. 10% contingency added for unforeseen technical challenges."}
                        {project.riskLevel === 'High' && "Significant uncertainty in scope or resources. 15% aggressive buffer recommended to ensure delivery."}
                      </p>
                    </div>
                  </section>

                  <section className="space-y-4">
                    <h3 className="text-xs font-mono uppercase tracking-widest opacity-50 flex items-center gap-2">
                      <Info className="w-4 h-4" /> Recommendations
                    </h3>
                    <ul className="space-y-3">
                      {[
                        `Allocate ${project.teamSize} dedicated resources for ${analysis.finalDurationDays} days.`,
                        `Maintain a strict ${analysis.bufferPercent}% budget reserve for scope creep.`,
                        `Conduct weekly milestone reviews to track against the ${analysis.totalWorkHours}h target.`,
                        project.teamSize > 5 ? "Consider sub-team leads to manage communication overhead." : "Direct communication model is efficient for this team size."
                      ].map((rec, i) => (
                        <li key={i} className="flex gap-3 text-xs leading-relaxed">
                          <CheckCircle2 className="w-4 h-4 shrink-0 opacity-50" />
                          <span>{rec}</span>
                        </li>
                      ))}
                    </ul>
                  </section>
                </div>
              </div>

              {/* Footer Actions */}
              <div className="flex justify-center pt-12">
                <button 
                  onClick={() => window.print()}
                  className="px-8 py-4 border-2 border-[#141414] font-bold uppercase tracking-widest hover:bg-[#141414] hover:text-[#E4E3E0] transition-all flex items-center gap-2"
                >
                  Export PDF Report
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Global Styles for Scrollbar */}
      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #141414;
          opacity: 0.2;
        }
        @media print {
          header, button, .no-print {
            display: none !important;
          }
          body {
            background: white !important;
          }
          .min-h-screen {
            min-height: auto !important;
          }
        }
      `}</style>
    </div>
  );
}
